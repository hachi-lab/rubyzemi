require 'phashion'
require 'open-uri'
require 'nokogiri'

=begin

#指定したサイトから画像URLの取得
url = "http://rubyzemi.herokuapp.com/posts"
html = Nokogiri::HTML(open(url))

ary = Array.new
html.css('img').each do |anchor| 
ary << anchor[:src]
end
ary.each do |url|
puts url
end

#画像URLをphashion使ってアレ
origin = Phashion::Image.new(ary[0])
phash = Array.new
ary.each do |file|
phash << Phashion::Image.new(file)
end

=end

#画像からハッシュオブジェクトの作成
ogn = Dir::glob("image_origin/*.jpg")
origin = Phashion::Image.new(ogn[0])

ary = Array.new
Dir::glob("images/*.jpg").each do |a|
ary << a
end

img = Array.new
ary.each do |f|
img << Phashion::Image.new(f)
end

#ハッシュ距離の算出
val = Array.new
img.each do |v|
val << origin.distance_from(v)
end

#ハッシュ距離と画像URLをハッシュにまとめる
alist = ary.zip(val)
Hash[alist]

#似てる画像を検出・提示
alist.each do |key, val|
if val <= 20 then
puts "similar picture is #{key}"
end
end
