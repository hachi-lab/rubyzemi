require 'open-uri'
require 'nokogiri'
require 'rubygems'
require "fileutils"

def save_image(url)
	fileName = File.basename(url) + ".jpg"
	dirName = "/image_download/downloads"
	filePath = dirName + fileName
	FileUtils.mkdir_p(dirName) unless FileTest.exist?(dirName)
	open(filePath, 'wb') do |output|
		open(url) do |data|
			output.write(data.read)
		end
	end
end

url = 'http://localhost:3000/posts'
page = Nokogiri::HTML(open(url))   

array = Array.new
page.css('img').each do |anchor| 
	array.push(anchor[:src])
end 

array.each do |url|
	save_image(url)
end
